package com.example.deardiary;

import junit.framework.TestCase;

public class NoteTest extends TestCase {

}