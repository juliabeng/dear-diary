package com.example.deardiary;

public class EmojiPosition {
    public EmojiPosition(float x, float y) {
    }

    public float getX() {
        return 0;
    }

    public float getY() {
        return 0;
    }
}
