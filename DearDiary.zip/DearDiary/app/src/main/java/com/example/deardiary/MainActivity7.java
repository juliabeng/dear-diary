package com.example.deardiary;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.AppCompatImageButton;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FieldValue;

public class MainActivity7 extends AppCompatActivity {

    private EditText editTextDescription;
    private Button saveButton;
    private AppCompatImageButton imageButton4, imageButton2, imageButton5, imageButton, imageButton7;
    private FirebaseFirestore db;
    private View button;

    @SuppressLint({"MissingInflatedId", "WrongViewCast"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main7);

        db = FirebaseFirestore.getInstance();

        // Initialize UI components
        editTextDescription = findViewById(R.id.editTextTextMultiLine2);
        saveButton = findViewById(R.id.button2);

        // Set initial EditText state
        editTextDescription.setText(AppState.getInstance().getCurrentDescription());

        // Sync EditText value to AppState (in memory) whenever a change is made
        editTextDescription.addTextChangedListener(new android.text.TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {}

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                AppState.getInstance().setCurrentDescription(s.toString());
            }

            @Override
            public void afterTextChanged(android.text.Editable s) {}
        });

        // Handle save button click
        saveButton.setOnClickListener(v -> saveToFirestore());

        // Set navigation buttons
        imageButton4 = findViewById(R.id.imageButton4);
        imageButton2 = findViewById(R.id.imageButton2);
        imageButton5 = findViewById(R.id.imageButton5);
        imageButton = findViewById(R.id.imageButton);
        imageButton7 = findViewById(R.id.imageButton7);
        button = findViewById(R.id.button);

        imageButton4.setOnClickListener(v -> navigateTo(MainActivity8.class));
        imageButton2.setOnClickListener(v -> navigateTo(Main66Activity.class));
        imageButton5.setOnClickListener(v -> navigateTo(MainActivity9.class));
        imageButton.setOnClickListener(v -> navigateTo(MainActivity10.class));
        imageButton7.setOnClickListener(v -> navigateTo(MainActivity5.class));
        button.setOnClickListener(v -> navigateTo(MainActivity4.class));
    }

    private void saveToFirestore() {
        String description = editTextDescription.getText().toString().trim();

        if (description.isEmpty()) {
            Toast.makeText(this, "Please enter a description", Toast.LENGTH_SHORT).show();
            return;
        }

        ToDoItem item = new ToDoItem(description, FieldValue.serverTimestamp());

        db.collection("todo_lists")
                .add(item)
                .addOnSuccessListener(documentReference -> {
                    Toast.makeText(MainActivity7.this, "Saved Successfully", Toast.LENGTH_SHORT).show();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(MainActivity7.this, "Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void navigateTo(Class<?> destination) {
        Intent intent = new Intent(MainActivity7.this, destination);
        startActivity(intent);
    }

    public static class ToDoItem {
        private String description;
        private Object timestamp; // Use Object to handle Firestore timestamp

        public ToDoItem() {}

        public ToDoItem(String description, Object timestamp) {
            this.description = description;
            this.timestamp = timestamp;
        }

        public String getDescription() {
            return description;
        }

        public void setDescription(String description) {
            this.description = description;
        }

        public Object getTimestamp() {
            return timestamp;
        }

        public void setTimestamp(Object timestamp) {
            this.timestamp = timestamp;
        }
    }
}
