package com.example.deardiary;

public class Note {
    private String title;
    private String content;
    private String timestamp;
    private String userId;

    public Note(String title, String content, String timestamp) {}

    public Note(String title, String content, String timestamp, String userId) {
        this.title = title;
        this.content = content;
        this.timestamp = timestamp;
        this.userId = userId;
    }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getTimestamp() { return timestamp; }
    public void setTimestamp(String timestamp) { this.timestamp = timestamp; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }
}
