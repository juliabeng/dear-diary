package com.example.deardiary;

public class val {
    public boolean isEmpty() {
        return false;
    }
}
