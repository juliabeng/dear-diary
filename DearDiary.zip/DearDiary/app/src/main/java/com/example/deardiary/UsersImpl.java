package com.example.deardiary;

public class UsersImpl extends Users {
    public UsersImpl(String email) {
        super(email);
    }
}
