package com.example.deardiary;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.util.Patterns;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

public class MainActivity3 extends AppCompatActivity {

    private FirebaseAuth mAuth;
    private EditText editTextEmail;
    private EditText editTextPassword;
    private EditText editTextConfirmPassword;  // Add this line
    private Button btnSignUp;
    private Button move;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        // Initialize Firebase authentication
        mAuth = FirebaseAuth.getInstance();

        // Find views and cast them properly
        editTextEmail = findViewById(R.id.editTextTextEmailAddress2);
        editTextPassword = findViewById(R.id.editTextTextPassword2);
        editTextConfirmPassword = findViewById(R.id.editTextTextPassword3);  // Add this line
        btnSignUp = findViewById(R.id.button7);
        move = findViewById(R.id.button8);

        // Set up navigation to login
        move.setOnClickListener(v -> navigateToLogin());

        // Set up sign-up logic
        btnSignUp.setOnClickListener(v -> signUp());
    }

    private void signUp() {
        String email = editTextEmail.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String confirmPassword = editTextConfirmPassword.getText().toString().trim();

        // Input validation
        if (email.isEmpty() || password.isEmpty() || confirmPassword.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if the email format is valid using a stricter regex pattern
        if (!isValidEmail(email)) {
            Toast.makeText(this, "Invalid email format. Please enter a valid email address.", Toast.LENGTH_SHORT).show();
            return; // Prevent the sign-up from proceeding
        }

        if (password.length() < 6) {
            Toast.makeText(this, "Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            Toast.makeText(this, "Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        // Firebase sign-up
        mAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        // If sign-up succeeds, navigate to login
                        Toast.makeText(this, "Sign up successful. Redirecting to login.", Toast.LENGTH_SHORT).show();
                        navigateToLogin();
                    } else {
                        if (task.getException() instanceof FirebaseAuthUserCollisionException) {
                            Toast.makeText(this, "User already exists. Redirecting to login.", Toast.LENGTH_SHORT).show();
                            navigateToLogin();
                        } else {
                            Toast.makeText(this, "Signup Failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    // Enhanced email validation using a stricter regex pattern
    public boolean isValidEmail(String email) {
        // This regex enforces a stricter format and checks the domain part more effectively
        String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";

        // Match the basic pattern first
        if (!email.matches(emailPattern)) {
            return false;
        }

        // Now check for specific domain-related issues, e.g., invalid domain like "gmai.com"
        String domain = email.substring(email.indexOf("@") + 1);

        // Here, you can check for common typos in domains (like 'gmai.com' instead of 'gmail.com')
        if (domain.contains("gmai.") || domain.contains("gnail.") || domain.contains("yaho.") || domain.contains("outlk.") ) {
            return false;  // Prevent sign-up if common typos in the domain are found
        }

        return true;
    }

    private void navigateToLogin() {
        Log.d("NavigateToLogin", "Navigating to MainActivity2...");
        Intent intent = new Intent(MainActivity3.this, MainActivity2.class);
        startActivity(intent);
        finish(); // Prevent user from navigating back to MainActivity3
    }
}
