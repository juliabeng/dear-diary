package com.example.deardiary;

import android.content.Intent;

public class GoogleSignInClient {
    public Intent getSignInIntent() {
        return null;
    }
}
