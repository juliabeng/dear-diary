package com.example.deardiary;

class TodoItem {
    // Field for storing the to-do description
    public String description;

    // Default public no-argument constructor (required by Firestore for deserialization)
    public TodoItem() {
    }

    // Parameterized constructor for saving to Firestore
    public TodoItem(String description) {
        this.description = description;
    }

    public String getDescription() {
        return null;
    }
}
