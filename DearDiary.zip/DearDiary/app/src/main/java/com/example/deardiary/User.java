package com.example.deardiary;

public class User {
    public User(String email) {
    }
}
