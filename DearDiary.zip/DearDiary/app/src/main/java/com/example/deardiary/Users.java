package com.example.deardiary;

public class Users {
    public Users(String email) {
    }
}
