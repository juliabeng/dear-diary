package com.example.deardiary;

import android.view.View;

public class TextView {
    public void setOnClickListener(View.OnClickListener onClickListener) {

    }

    public void setText(String s) {

    }
}
