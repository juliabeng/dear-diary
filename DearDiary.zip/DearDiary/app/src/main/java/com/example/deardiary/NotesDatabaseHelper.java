package com.example.deardiary;

import android.database.sqlite.SQLiteDatabase;

public class NotesDatabaseHelper {
    public static final String COLUMN_TITLE =("title") ;
    public static final String COLUMN_CONTENT =("content") ;
    public static final String COLUMN_TIMESTAMP =("timestamp");
    public static final String TABLE_NAME =("name") ;

    public NotesDatabaseHelper(Main66Activity main66Activity) {

    }

    public SQLiteDatabase getWritableDatabase() {
        return null;
    }
}
