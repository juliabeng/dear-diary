package com.example.deardiary;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Main66Activity extends AppCompatActivity {

    private EditText etNoteTitle, etNoteContent;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main66);

        // Initialize Firestore instance
        firestore = FirebaseFirestore.getInstance();

        // Set up navigation buttons safely
        setupNavigationButtons();

        // Set up Save button for notes
        etNoteTitle = findViewById(R.id.editTextText3);
        etNoteContent = findViewById(R.id.editTextTextMultiLine);
        Button btnSaveNote = findViewById(R.id.button22);

        // Null check for EditText fields and button
        if (etNoteTitle == null || etNoteContent == null || btnSaveNote == null) {
            Toast.makeText(this, "Error loading fields or button. Check IDs.", Toast.LENGTH_SHORT).show();
        } else {
            btnSaveNote.setOnClickListener(v -> saveNoteToFirestore());
        }
    }

    private void setupNavigationButtons() {
        try {
            findViewById(R.id.imageButton3).setOnClickListener(v -> navigateToActivity(MainActivity7.class));
            findViewById(R.id.imageButton4).setOnClickListener(v -> navigateToActivity(MainActivity8.class));
            findViewById(R.id.imageButton5).setOnClickListener(v -> navigateToActivity(MainActivity9.class));
            findViewById(R.id.imageButton).setOnClickListener(v -> navigateToActivity(MainActivity10.class));
            findViewById(R.id.imageButton7).setOnClickListener(v -> navigateToActivity(MainActivity5.class));
            findViewById(R.id.button).setOnClickListener(v -> navigateToActivity(MainActivity4.class));
        } catch (Exception e) {
            Toast.makeText(this, "Navigation setup failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void navigateToActivity(Class<?> targetActivity) {
        try {
            Intent intent = new Intent(Main66Activity.this, targetActivity);
            startActivity(intent);
        } catch (Exception e) {
            Toast.makeText(this, "Navigation failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void saveNoteToFirestore() {
        String title = etNoteTitle.getText().toString().trim();
        String content = etNoteContent.getText().toString().trim();

        if (title.isEmpty() || content.isEmpty()) {
            Toast.makeText(this, "Both fields are required!", Toast.LENGTH_SHORT).show();
            return;
        }

        // Get the current user ID
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        // Generate current date/time as a timestamp string
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        // Create note object
        Note note = new Note(title, content, timestamp, userId);

        firestore.collection("notes") // Reference to the 'notes' collection
                .document() // Generate a unique document ID automatically
                .set(note)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(Main66Activity.this, "Note saved successfully!", Toast.LENGTH_SHORT).show();
                    clearFields();
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(Main66Activity.this, "Failed to save note: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }


    private void clearFields() {
        etNoteTitle.setText("");
        etNoteContent.setText("");
    }
}
