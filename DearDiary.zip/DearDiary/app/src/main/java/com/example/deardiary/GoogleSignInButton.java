package com.example.deardiary;

import android.view.View;

public class GoogleSignInButton {
    public void setOnClickListener(View.OnClickListener onClickListener) {

    }
}
