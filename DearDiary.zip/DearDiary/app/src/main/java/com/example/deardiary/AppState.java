package com.example.deardiary;

public class AppState {
    private static AppState instance;
    private String currentDescription = "";

    private AppState() {}

    public static AppState getInstance() {
        if (instance == null) {
            instance = new AppState();
        }
        return instance;
    }

    public String getCurrentDescription() {
        return currentDescription;
    }

    public void setCurrentDescription(String description) {
        this.currentDescription = description;
    }
}
