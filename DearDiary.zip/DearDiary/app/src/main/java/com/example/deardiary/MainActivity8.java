package com.example.deardiary;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.DocumentReference;

import java.util.ArrayList;

public class MainActivity8 extends AppCompatActivity {

    private ArrayList<TextView> draggableEmojis = new ArrayList<>();
    private ImageView gridImage;

    private float dX, dY; // Touch offsets for dragging
    private FirebaseFirestore db;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main8);

        // Initialize Firestore
        db = FirebaseFirestore.getInstance();

        // Reference the draggable grid bounds
        gridImage = findViewById(R.id.imageView19);

        // Collect draggable emoji references
        draggableEmojis.add(findViewById(R.id.textView15));
        draggableEmojis.add(findViewById(R.id.textView16));
        draggableEmojis.add(findViewById(R.id.textView17));
        draggableEmojis.add(findViewById(R.id.textView18));
        draggableEmojis.add(findViewById(R.id.textView19));

        // Attach touch listeners
        for (TextView emoji : draggableEmojis) {
            emoji.setOnTouchListener(onTouchListener);
        }

        // Add navigation to another activity
        setupNavigation();
    }

    private final View.OnTouchListener onTouchListener = new View.OnTouchListener() {
        @Override
        public boolean onTouch(View v, MotionEvent event) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    // Record initial touch offsets
                    dX = event.getRawX() - v.getX();
                    dY = event.getRawY() - v.getY();
                    Log.d("TouchEvent", "ACTION_DOWN: dX=" + dX + ", dY=" + dY);
                    return true;

                case MotionEvent.ACTION_MOVE:
                    // Calculate new position
                    float newX = event.getRawX() - dX;
                    float newY = event.getRawY() - dY;

                    // Clamp position within gridImage bounds
                    newX = clampX(newX, v.getWidth());
                    newY = clampY(newY, v.getHeight());

                    // Apply new position
                    v.setX(newX);
                    v.setY(newY);

                    // Save the emoji's new position to Firestore
                    saveEmojiPositionToFirestore(newX, newY);

                    Log.d("TouchEvent", "ACTION_MOVE: x=" + newX + ", y=" + newY);
                    return true;

                default:
                    return false;
            }
        }
    };

    /**
     * Save the emoji's position to Firestore.
     */
    private void saveEmojiPositionToFirestore(float x, float y) {
        EmojiPosition emojiPosition = new EmojiPosition(x, y);

        // Create a reference to the Firestore document
        String emojiIndex = null;
        DocumentReference emojiRef = db.collection("emojiPositions")
                .document("emoji_" + emojiIndex); // Use index to differentiate each emoji

        emojiRef.set(emojiPosition)
                .addOnSuccessListener(aVoid -> {
                    Log.d("Firestore", "Emoji position saved: " + emojiPosition);
                })
                .addOnFailureListener(e -> {
                    Log.e("Firestore", "Error saving emoji position", e);
                    Toast.makeText(MainActivity8.this, "Failed to save position", Toast.LENGTH_SHORT).show();
                });
    }

    /**
     * Restore emoji positions from Firestore.
     */
    private void restoreEmojiPositions() {
        for (int i = 0; i < draggableEmojis.size(); i++) {
            final int emojiIndex = i;

            // Get the position data for each emoji from Firestore
            DocumentReference emojiRef = db.collection("emojiPositions")
                    .document("emoji_" + emojiIndex);

            emojiRef.get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            EmojiPosition emojiPosition = documentSnapshot.toObject(EmojiPosition.class);
                            if (emojiPosition != null) {
                                TextView emoji = draggableEmojis.get(emojiIndex);
                                emoji.setX(emojiPosition.getX());
                                emoji.setY(emojiPosition.getY());
                                Log.d("Firestore", "Restored emoji " + emojiIndex + " position: " + emojiPosition);
                            }
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e("Firestore", "Error retrieving emoji position", e);
                    });
        }
    }

    /**
     * Clamp horizontal movement so emojis stay within the visible bounds of gridImage.
     */
    private float clampX(float x, int emojiWidth) {
        float leftBound = gridImage.getX();
        float rightBound = gridImage.getX() + gridImage.getWidth() - emojiWidth;
        return Math.max(leftBound, Math.min(x, rightBound));
    }

    /**
     * Clamp vertical movement so emojis stay within the visible bounds of gridImage.
     */
    private float clampY(float y, int emojiHeight) {
        float topBound = gridImage.getY();
        float bottomBound = gridImage.getY() + gridImage.getHeight() - emojiHeight;
        return Math.max(topBound, Math.min(y, bottomBound));
    }

    /**
     * Setup navigation to other activities when a specific button is clicked.
     */
    private void setupNavigation() {
        // Set up navigation buttons
        initializeButton(R.id.imageButton5, MainActivity9.class);
        initializeButton(R.id.imageButton2, Main66Activity.class);
        initializeButton(R.id.imageButton3, MainActivity7.class);
        initializeButton(R.id.imageButton, MainActivity10.class);
        initializeButton(R.id.imageButton7, MainActivity5.class);
        initializeButton(R.id.button, MainActivity4.class);
    }

    /**
     * Helper method to initialize buttons with click listeners for navigation.
     */
    private void initializeButton(int buttonId, Class<?> targetActivity) {
        View button = findViewById(buttonId);
        if (button != null) {
            button.setOnClickListener(v -> {
                try {
                    // Save emoji position before navigating
                    saveAllEmojisPositions();

                    // Navigate to the target activity
                    Intent intent = new Intent(MainActivity8.this, targetActivity);
                    startActivity(intent);
                } catch (Exception e) {
                    Toast.makeText(this, "Failed to navigate: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            Log.w("Navigation", "Button with ID " + buttonId + " not found in layout.");
        }
    }

    private void saveAllEmojisPositions() {
    }

    @Override
    protected void onPause() {
        super.onPause();
        // Save all emoji positions before the activity is paused
        saveAllEmojisPositions();
    }

    @Override
    protected void onResume() {
        super.onResume();
        // Restore emoji positions when the activity is resumed
        restoreEmojiPositions();
    }
}
