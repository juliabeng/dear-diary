package com.example.deardiary;

public class TodoAdapter {
}
