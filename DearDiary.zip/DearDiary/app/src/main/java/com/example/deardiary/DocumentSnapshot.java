package com.example.deardiary;

import android.provider.ContactsContract;

public class DocumentSnapshot {
    public ContactsContract.CommonDataKinds.Note toObject(Class<ContactsContract.CommonDataKinds.Note> noteClass) {
        return null;
    }
}
